<!DOCTYPE html>
  <html lang="es">
  <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Accesorios Ranyela Gómez</title>

  <!-- Bootstrap -->
  <link href="<?= $recursos ?>/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
  <link href="<?= $recursos ?>/css/style.css" rel="stylesheet">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  </head>
  <body>
 


      

<header id="main-header">

  <!-- ZONA 01: LOGIN - INSCRIBIRSE - CARRITO -->
  <div class="container">
        <div class="row">
           <!--
               INSCRIBIRSE - LOGIN - CARRITO 
            -->
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="btn-group botones-superiores-registrado">                      
                      <button class="btn btn-primary dropdown-toggle" id="submenu-registrado" type="button" data-toggle="dropdown" aria-expanded="true">
                        <img src="<?= $recursos ?>/img/ingresa_icon.png" id="ingresa-Usuario">
                          <?php echo  ''.$user['nombre'].' '.$user['apellido']; ?>
                          <span class="caret"></span>
                        
                        </button>

                        <!-- SUBMENU DEL USUARIO REGISTRADO - SALIR -->
                        <ul class="dropdown-menu" role="menu" aria-labelledby="submenu-registrado">
                          <li role="presentation"><a role="menuitem" tabindex="-1" href="<?= site_url('principal/logout') ?>">Salir</a></li>
                        </ul>

                        <!-- FIN SUBMENU -->

                      <button class="btn btn-default btn-superior" onclick="location.href='<?=site_url('principal/carrito') ?>'"><img src="<?= $recursos ?>/img/carrito-icono.png" alt="">Carrito: (4)</button>
                    </div>
            </div>
          
        </div>
  </div>

  <!--
      lOGOTIPO - MENU
  -->
  <div class="container">
        <div class="row">
           <!--
               LOGO
            -->
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                <div id="main-logo">
                    <a href="<?= site_url('principal/index') ?>"><img src="<?= $recursos ?>/img/ranyela-logotipo.png" alt="logotipo"></a>
                </div>
            </div>
            
            <!-- 
                MENU
            -->
            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                  <nav>        
                      <ul class="menu-principal pull-right">
                          <li id="home-icon"><a href="<?= site_url('principal/index')?>" id="home-icon"><span class="glyphicon glyphicon-home"></span></a></li>
                          <li><a href="#">GARGANTILLAS</a></li>
                          <li><a href="#">PULSERAS</a></li>
                          <li><a href="#">ZARCILLOS</a></li>
                          <li><a href="<?= site_url('principal/contacto') ?>">CONTACTO</a></li>
                      </ul>
                  </nav>
                
            </div>
        </div>
  </div>
</header>