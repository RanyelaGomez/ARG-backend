</body>
<footer>
      <div class="container">
          <div class="row">
            <div class="col-md-3">
                <div class="logo-footer">
                  <img src="<?= $recursos ?>/img/logo-footer.png" alt="Ranyela Gómez - Accesorios">
                </div>
            </div>
            <div class="col-md-3 col-md-offset-6">
                <div class="social">
                    <span id="titulo-sociales">¡Síguenos en las Redes Sociales!</span>
                    <div class="social-media">
                        <a href="#"><img src="<?= $recursos ?>/img/facebook-icon.png" alt=""></a>
                        <a href="#"><img src="<?= $recursos ?>/img/twitter-icon.png" alt=""></a>
                        <a href="#"><img src="<?= $recursos ?>/img/instagram-icon.png" alt=""></a>
                    </div>
                </div>
            </div>
          </div>

          <!--
              DERECHOS RESERVADOS
          -->
          <div class="row">
              <div class="col-md-12">
                <h5 id="derechos-reservados">Ranyela Gómez Accesorios - Copyright 2014 - Todos los Derechos Reservados - Hecho en Venezuela</h5>
              </div>
          </div>
      </div>

  </footer>
  </html>
