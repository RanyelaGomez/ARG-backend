<footer>
      <div class="container">
          <div class="row">
            <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                <div class="logo-footer">
                  <img src="<?= $recursos ?>/img/logo-footer.png" alt="Ranyela Gomez - Accesorios">
                </div>
            </div>
            <div class="col-xs-6 col-xs-offset-3 col-sm-4 col-sm-offset-5 col-md-3 col-md-offset-6">
                <div class="social">
                    <span id="titulo-sociales">¡Siguenos en las Redes Sociales!</span>
                    <div class="social-media">
                        <a href="https://www.facebook.com/pages/Accesorios-Ranyela-Gomez/1429184814020503?ref=aymt_homepage_panelAccesorios Ranyela Gomez"><img src="<?= $recursos ?>/img/facebook-icon.png" alt=""></a>
                        <a href="https://twitter.com/Accesoriosrg"><img src="<?= $recursos ?>/img/twitter-icon.png" alt=""></a>
                        <a href="http://instagram.com/accesorios_ranyelagomez"><img src="<?= $recursos ?>/img/instagram-icon.png" alt=""></a>
                    </div>
                </div>              
            </div>
          </div>

          <!--
              DERECHOS RESERVADOS
          -->
          <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <h5 id="derechos-reservados">Ranyela Gomez Accesorios - Copyright 2014 - Todos los Derechos Reservados - Hecho en Venezuela</h5>
              </div>
          </div>
      </div>
    
  </footer>

