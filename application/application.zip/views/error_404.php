

  <body class="error-body">
    <section class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <div class="error-md">
            <img src="<?=$recursos?>/img/error404.png" class="img-responsive" alt="">
          </div>
        </div>
      </div>
    </section>   

  </body>

  