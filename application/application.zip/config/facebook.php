<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['appId']  = '536311206510536';
$config['secret'] = '5b877512cd86b22da1b8ed7bfcd71ee4';


