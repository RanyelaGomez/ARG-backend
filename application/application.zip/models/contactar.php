<?php

@$nombre = addslashes($_POST['nombre']);
@$asunto = addslashes($_POST['asunto']);
@$mensaje = addslashes($_POST['mensaje']);
@$email = addslashes($_POST['email']);



//Preparamos el mensaje de contacto
$cabeceras = "From: $email\n" //La persona que envia el correo
 . "Reply-To: $email\n";
$asunto = "$asunto"; //asunto aparecera en la bandeja del servidor de correo
$email_to = "info@accesoriosranyelagomez.com.ve"; //cambiar por tu email
$contenido = "$nombre \n"
. "\n"
. "Nombre: $nombre\n"
. "Email: $email\n"
. "Mensaje: $mensaje\n"
. "\n";
//Enviamos el mensaje y comprobamos el resultado

mail($email_to, $asunto ,$contenido ,$cabeceras);

?>